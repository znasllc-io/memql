This folder holds an account of a MemQL cluster: Acme (acc0001).

It was taken from memql.example at 2026-11-12T09:30:00Z, by engine 0.32.0, as export exp0001.
Every line in it comes from that one instant. File format version: 1.

WHAT IS IN IT

  v1:accounts:account                      1 row, 2 versions
  v1:library:file                          2 rows, 3 versions
  v1:todos:todo                            1 row, 1 version

  Bytes: 1 object, 35 bytes.
  Missing at the source before this file was taken: 1 object, each named in bytes.jsonl.
  people.jsonl: 2 lines.
  references.jsonl: 1 line.
  connections.jsonl: 0 lines.

WHAT IS LEFT OUT

  v1:platform:siteAccessSession            3 rows stayed on the cluster (signin: sign-in material and visits).
  v1:todos:todo                            2 rows in no account, which belong to nobody.
  v1:todos:todo.token is a secret; its value was removed from every version.
  Counted, not carried (only older versions or package snapshots point at them): 1 object, 10 bytes where the size is known, 0 of unknown size.
  Rebuilt on the cluster that takes this file, from what is in it: vectors, email statistics, site health.

CHECKING IT

  SHA256SUMS lists every other file in this folder with its SHA-256. To check them all,
  from the folder that holds this one:

    cd acme-2026-11-12.memql-account && sha256sum -c SHA256SUMS

  On macOS, use `shasum -a 256 -c SHA256SUMS` in place of sha256sum.

OPENING A PROTECTED FILE

  This file was not protected.
  A protected file ends in .tar.age. Open it with age (https://age-encryption.org) and its passphrase, then unpack it:

    age --decrypt -o acme-2026-11-12.memql-account.tar acme-2026-11-12.memql-account.tar.age && tar -xf acme-2026-11-12.memql-account.tar
